﻿namespace torpedo_v1
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.S_C1 = new System.Windows.Forms.Button();
            this.S_E5 = new System.Windows.Forms.Button();
            this.S_D5 = new System.Windows.Forms.Button();
            this.S_C5 = new System.Windows.Forms.Button();
            this.S_B5 = new System.Windows.Forms.Button();
            this.S_A5 = new System.Windows.Forms.Button();
            this.S_E4 = new System.Windows.Forms.Button();
            this.S_D4 = new System.Windows.Forms.Button();
            this.S_C4 = new System.Windows.Forms.Button();
            this.S_B4 = new System.Windows.Forms.Button();
            this.S_A4 = new System.Windows.Forms.Button();
            this.S_E3 = new System.Windows.Forms.Button();
            this.S_D3 = new System.Windows.Forms.Button();
            this.S_C3 = new System.Windows.Forms.Button();
            this.S_B3 = new System.Windows.Forms.Button();
            this.S_A3 = new System.Windows.Forms.Button();
            this.S_E2 = new System.Windows.Forms.Button();
            this.S_D2 = new System.Windows.Forms.Button();
            this.S_C2 = new System.Windows.Forms.Button();
            this.S_B2 = new System.Windows.Forms.Button();
            this.S_A2 = new System.Windows.Forms.Button();
            this.S_E1 = new System.Windows.Forms.Button();
            this.S_D1 = new System.Windows.Forms.Button();
            this.S_B1 = new System.Windows.Forms.Button();
            this.S_A1 = new System.Windows.Forms.Button();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.button26 = new System.Windows.Forms.Button();
            this.button27 = new System.Windows.Forms.Button();
            this.button28 = new System.Windows.Forms.Button();
            this.button29 = new System.Windows.Forms.Button();
            this.button30 = new System.Windows.Forms.Button();
            this.button31 = new System.Windows.Forms.Button();
            this.button32 = new System.Windows.Forms.Button();
            this.button33 = new System.Windows.Forms.Button();
            this.button34 = new System.Windows.Forms.Button();
            this.button35 = new System.Windows.Forms.Button();
            this.button36 = new System.Windows.Forms.Button();
            this.button37 = new System.Windows.Forms.Button();
            this.button38 = new System.Windows.Forms.Button();
            this.button39 = new System.Windows.Forms.Button();
            this.button40 = new System.Windows.Forms.Button();
            this.button41 = new System.Windows.Forms.Button();
            this.button42 = new System.Windows.Forms.Button();
            this.button43 = new System.Windows.Forms.Button();
            this.button44 = new System.Windows.Forms.Button();
            this.button45 = new System.Windows.Forms.Button();
            this.button46 = new System.Windows.Forms.Button();
            this.button47 = new System.Windows.Forms.Button();
            this.button48 = new System.Windows.Forms.Button();
            this.button49 = new System.Windows.Forms.Button();
            this.button50 = new System.Windows.Forms.Button();
            this.button51 = new System.Windows.Forms.Button();
            this.radioButton1 = new System.Windows.Forms.RadioButton();
            this.radioButton2 = new System.Windows.Forms.RadioButton();
            this.radioButton3 = new System.Windows.Forms.RadioButton();
            this.radioButton4 = new System.Windows.Forms.RadioButton();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.tajekoztato = new System.Windows.Forms.Label();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.S_C1);
            this.groupBox1.Controls.Add(this.S_E5);
            this.groupBox1.Controls.Add(this.S_D5);
            this.groupBox1.Controls.Add(this.S_C5);
            this.groupBox1.Controls.Add(this.S_B5);
            this.groupBox1.Controls.Add(this.S_A5);
            this.groupBox1.Controls.Add(this.S_E4);
            this.groupBox1.Controls.Add(this.S_D4);
            this.groupBox1.Controls.Add(this.S_C4);
            this.groupBox1.Controls.Add(this.S_B4);
            this.groupBox1.Controls.Add(this.S_A4);
            this.groupBox1.Controls.Add(this.S_E3);
            this.groupBox1.Controls.Add(this.S_D3);
            this.groupBox1.Controls.Add(this.S_C3);
            this.groupBox1.Controls.Add(this.S_B3);
            this.groupBox1.Controls.Add(this.S_A3);
            this.groupBox1.Controls.Add(this.S_E2);
            this.groupBox1.Controls.Add(this.S_D2);
            this.groupBox1.Controls.Add(this.S_C2);
            this.groupBox1.Controls.Add(this.S_B2);
            this.groupBox1.Controls.Add(this.S_A2);
            this.groupBox1.Controls.Add(this.S_E1);
            this.groupBox1.Controls.Add(this.S_D1);
            this.groupBox1.Controls.Add(this.S_B1);
            this.groupBox1.Controls.Add(this.S_A1);
            this.groupBox1.Location = new System.Drawing.Point(13, 13);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(404, 206);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Saját";
            // 
            // S_C1
            // 
            this.S_C1.Location = new System.Drawing.Point(164, 50);
            this.S_C1.Name = "S_C1";
            this.S_C1.Size = new System.Drawing.Size(75, 23);
            this.S_C1.TabIndex = 49;
            this.S_C1.Text = "button3";
            this.S_C1.UseVisualStyleBackColor = true;
            this.S_C1.Click += new System.EventHandler(this.btn_click);
            // 
            // S_E5
            // 
            this.S_E5.Location = new System.Drawing.Point(329, 168);
            this.S_E5.Name = "S_E5";
            this.S_E5.Size = new System.Drawing.Size(75, 23);
            this.S_E5.TabIndex = 48;
            this.S_E5.Text = "button25";
            this.S_E5.UseVisualStyleBackColor = true;
            this.S_E5.Click += new System.EventHandler(this.btn_click);
            // 
            // S_D5
            // 
            this.S_D5.Location = new System.Drawing.Point(246, 168);
            this.S_D5.Name = "S_D5";
            this.S_D5.Size = new System.Drawing.Size(75, 23);
            this.S_D5.TabIndex = 47;
            this.S_D5.Text = "button24";
            this.S_D5.UseVisualStyleBackColor = true;
            this.S_D5.Click += new System.EventHandler(this.btn_click);
            // 
            // S_C5
            // 
            this.S_C5.Location = new System.Drawing.Point(164, 168);
            this.S_C5.Name = "S_C5";
            this.S_C5.Size = new System.Drawing.Size(75, 23);
            this.S_C5.TabIndex = 46;
            this.S_C5.Text = "button23";
            this.S_C5.UseVisualStyleBackColor = true;
            this.S_C5.Click += new System.EventHandler(this.btn_click);
            // 
            // S_B5
            // 
            this.S_B5.Location = new System.Drawing.Point(83, 168);
            this.S_B5.Name = "S_B5";
            this.S_B5.Size = new System.Drawing.Size(75, 23);
            this.S_B5.TabIndex = 45;
            this.S_B5.Text = "button22";
            this.S_B5.UseVisualStyleBackColor = true;
            this.S_B5.Click += new System.EventHandler(this.btn_click);
            // 
            // S_A5
            // 
            this.S_A5.Location = new System.Drawing.Point(1, 168);
            this.S_A5.Name = "S_A5";
            this.S_A5.Size = new System.Drawing.Size(75, 23);
            this.S_A5.TabIndex = 44;
            this.S_A5.Text = "S_A5";
            this.S_A5.UseVisualStyleBackColor = true;
            this.S_A5.Click += new System.EventHandler(this.btn_click);
            // 
            // S_E4
            // 
            this.S_E4.Location = new System.Drawing.Point(328, 138);
            this.S_E4.Name = "S_E4";
            this.S_E4.Size = new System.Drawing.Size(75, 23);
            this.S_E4.TabIndex = 43;
            this.S_E4.Text = "button20";
            this.S_E4.UseVisualStyleBackColor = true;
            this.S_E4.Click += new System.EventHandler(this.btn_click);
            // 
            // S_D4
            // 
            this.S_D4.Location = new System.Drawing.Point(246, 138);
            this.S_D4.Name = "S_D4";
            this.S_D4.Size = new System.Drawing.Size(75, 23);
            this.S_D4.TabIndex = 42;
            this.S_D4.Text = "button19";
            this.S_D4.UseVisualStyleBackColor = true;
            this.S_D4.Click += new System.EventHandler(this.btn_click);
            // 
            // S_C4
            // 
            this.S_C4.Location = new System.Drawing.Point(164, 138);
            this.S_C4.Name = "S_C4";
            this.S_C4.Size = new System.Drawing.Size(75, 23);
            this.S_C4.TabIndex = 41;
            this.S_C4.Text = "button18";
            this.S_C4.UseVisualStyleBackColor = true;
            this.S_C4.Click += new System.EventHandler(this.btn_click);
            // 
            // S_B4
            // 
            this.S_B4.Location = new System.Drawing.Point(82, 138);
            this.S_B4.Name = "S_B4";
            this.S_B4.Size = new System.Drawing.Size(75, 23);
            this.S_B4.TabIndex = 40;
            this.S_B4.Text = "button17";
            this.S_B4.UseVisualStyleBackColor = true;
            this.S_B4.Click += new System.EventHandler(this.btn_click);
            // 
            // S_A4
            // 
            this.S_A4.Location = new System.Drawing.Point(0, 138);
            this.S_A4.Name = "S_A4";
            this.S_A4.Size = new System.Drawing.Size(75, 23);
            this.S_A4.TabIndex = 39;
            this.S_A4.Text = "S_A4";
            this.S_A4.UseVisualStyleBackColor = true;
            this.S_A4.Click += new System.EventHandler(this.btn_click);
            // 
            // S_E3
            // 
            this.S_E3.Location = new System.Drawing.Point(329, 108);
            this.S_E3.Name = "S_E3";
            this.S_E3.Size = new System.Drawing.Size(75, 23);
            this.S_E3.TabIndex = 38;
            this.S_E3.Text = "button15";
            this.S_E3.UseVisualStyleBackColor = true;
            this.S_E3.Click += new System.EventHandler(this.btn_click);
            // 
            // S_D3
            // 
            this.S_D3.Location = new System.Drawing.Point(247, 108);
            this.S_D3.Name = "S_D3";
            this.S_D3.Size = new System.Drawing.Size(75, 23);
            this.S_D3.TabIndex = 37;
            this.S_D3.Text = "button14";
            this.S_D3.UseVisualStyleBackColor = true;
            this.S_D3.Click += new System.EventHandler(this.btn_click);
            // 
            // S_C3
            // 
            this.S_C3.Location = new System.Drawing.Point(165, 108);
            this.S_C3.Name = "S_C3";
            this.S_C3.Size = new System.Drawing.Size(75, 23);
            this.S_C3.TabIndex = 36;
            this.S_C3.Text = "button13";
            this.S_C3.UseVisualStyleBackColor = true;
            this.S_C3.Click += new System.EventHandler(this.btn_click);
            // 
            // S_B3
            // 
            this.S_B3.Location = new System.Drawing.Point(83, 108);
            this.S_B3.Name = "S_B3";
            this.S_B3.Size = new System.Drawing.Size(75, 23);
            this.S_B3.TabIndex = 35;
            this.S_B3.Text = "button12";
            this.S_B3.UseVisualStyleBackColor = true;
            this.S_B3.Click += new System.EventHandler(this.btn_click);
            // 
            // S_A3
            // 
            this.S_A3.Location = new System.Drawing.Point(1, 109);
            this.S_A3.Name = "S_A3";
            this.S_A3.Size = new System.Drawing.Size(75, 23);
            this.S_A3.TabIndex = 34;
            this.S_A3.Text = "S_A3";
            this.S_A3.UseVisualStyleBackColor = true;
            this.S_A3.Click += new System.EventHandler(this.btn_click);
            // 
            // S_E2
            // 
            this.S_E2.Location = new System.Drawing.Point(329, 79);
            this.S_E2.Name = "S_E2";
            this.S_E2.Size = new System.Drawing.Size(75, 23);
            this.S_E2.TabIndex = 33;
            this.S_E2.Text = "button10";
            this.S_E2.UseVisualStyleBackColor = true;
            this.S_E2.Click += new System.EventHandler(this.btn_click);
            // 
            // S_D2
            // 
            this.S_D2.Location = new System.Drawing.Point(247, 79);
            this.S_D2.Name = "S_D2";
            this.S_D2.Size = new System.Drawing.Size(75, 23);
            this.S_D2.TabIndex = 32;
            this.S_D2.Text = "button9";
            this.S_D2.UseVisualStyleBackColor = true;
            this.S_D2.Click += new System.EventHandler(this.btn_click);
            // 
            // S_C2
            // 
            this.S_C2.Location = new System.Drawing.Point(165, 79);
            this.S_C2.Name = "S_C2";
            this.S_C2.Size = new System.Drawing.Size(75, 23);
            this.S_C2.TabIndex = 31;
            this.S_C2.Text = "button8";
            this.S_C2.UseVisualStyleBackColor = true;
            this.S_C2.Click += new System.EventHandler(this.btn_click);
            // 
            // S_B2
            // 
            this.S_B2.Location = new System.Drawing.Point(83, 79);
            this.S_B2.Name = "S_B2";
            this.S_B2.Size = new System.Drawing.Size(75, 23);
            this.S_B2.TabIndex = 30;
            this.S_B2.Text = "button7";
            this.S_B2.UseVisualStyleBackColor = true;
            this.S_B2.Click += new System.EventHandler(this.btn_click);
            // 
            // S_A2
            // 
            this.S_A2.Location = new System.Drawing.Point(1, 79);
            this.S_A2.Name = "S_A2";
            this.S_A2.Size = new System.Drawing.Size(75, 23);
            this.S_A2.TabIndex = 29;
            this.S_A2.Text = "S_A2";
            this.S_A2.UseVisualStyleBackColor = true;
            this.S_A2.Click += new System.EventHandler(this.btn_click);
            // 
            // S_E1
            // 
            this.S_E1.Location = new System.Drawing.Point(329, 49);
            this.S_E1.Name = "S_E1";
            this.S_E1.Size = new System.Drawing.Size(75, 23);
            this.S_E1.TabIndex = 28;
            this.S_E1.Text = "button5";
            this.S_E1.UseVisualStyleBackColor = true;
            this.S_E1.Click += new System.EventHandler(this.btn_click);
            // 
            // S_D1
            // 
            this.S_D1.Location = new System.Drawing.Point(247, 49);
            this.S_D1.Name = "S_D1";
            this.S_D1.Size = new System.Drawing.Size(75, 23);
            this.S_D1.TabIndex = 27;
            this.S_D1.Text = "button4";
            this.S_D1.UseVisualStyleBackColor = true;
            this.S_D1.Click += new System.EventHandler(this.btn_click);
            // 
            // S_B1
            // 
            this.S_B1.Location = new System.Drawing.Point(83, 49);
            this.S_B1.Name = "S_B1";
            this.S_B1.Size = new System.Drawing.Size(75, 23);
            this.S_B1.TabIndex = 26;
            this.S_B1.Text = "button2";
            this.S_B1.UseVisualStyleBackColor = true;
            this.S_B1.Click += new System.EventHandler(this.btn_click);
            // 
            // S_A1
            // 
            this.S_A1.Location = new System.Drawing.Point(1, 49);
            this.S_A1.Name = "S_A1";
            this.S_A1.Size = new System.Drawing.Size(75, 23);
            this.S_A1.TabIndex = 25;
            this.S_A1.Text = "S_A1";
            this.S_A1.UseVisualStyleBackColor = true;
            this.S_A1.Click += new System.EventHandler(this.btn_click);
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.button26);
            this.groupBox2.Controls.Add(this.button27);
            this.groupBox2.Controls.Add(this.button28);
            this.groupBox2.Controls.Add(this.button29);
            this.groupBox2.Controls.Add(this.button30);
            this.groupBox2.Controls.Add(this.button31);
            this.groupBox2.Controls.Add(this.button32);
            this.groupBox2.Controls.Add(this.button33);
            this.groupBox2.Controls.Add(this.button34);
            this.groupBox2.Controls.Add(this.button35);
            this.groupBox2.Controls.Add(this.button36);
            this.groupBox2.Controls.Add(this.button37);
            this.groupBox2.Controls.Add(this.button38);
            this.groupBox2.Controls.Add(this.button39);
            this.groupBox2.Controls.Add(this.button40);
            this.groupBox2.Controls.Add(this.button41);
            this.groupBox2.Controls.Add(this.button42);
            this.groupBox2.Controls.Add(this.button43);
            this.groupBox2.Controls.Add(this.button44);
            this.groupBox2.Controls.Add(this.button45);
            this.groupBox2.Controls.Add(this.button46);
            this.groupBox2.Controls.Add(this.button47);
            this.groupBox2.Controls.Add(this.button48);
            this.groupBox2.Controls.Add(this.button49);
            this.groupBox2.Controls.Add(this.button50);
            this.groupBox2.Location = new System.Drawing.Point(438, 13);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(404, 206);
            this.groupBox2.TabIndex = 1;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Ellenfél";
            // 
            // button26
            // 
            this.button26.Location = new System.Drawing.Point(164, 50);
            this.button26.Name = "button26";
            this.button26.Size = new System.Drawing.Size(75, 23);
            this.button26.TabIndex = 49;
            this.button26.Text = "button26";
            this.button26.UseVisualStyleBackColor = true;
            // 
            // button27
            // 
            this.button27.Location = new System.Drawing.Point(329, 168);
            this.button27.Name = "button27";
            this.button27.Size = new System.Drawing.Size(75, 23);
            this.button27.TabIndex = 48;
            this.button27.Text = "button27";
            this.button27.UseVisualStyleBackColor = true;
            // 
            // button28
            // 
            this.button28.Location = new System.Drawing.Point(246, 168);
            this.button28.Name = "button28";
            this.button28.Size = new System.Drawing.Size(75, 23);
            this.button28.TabIndex = 47;
            this.button28.Text = "button28";
            this.button28.UseVisualStyleBackColor = true;
            // 
            // button29
            // 
            this.button29.Location = new System.Drawing.Point(164, 168);
            this.button29.Name = "button29";
            this.button29.Size = new System.Drawing.Size(75, 23);
            this.button29.TabIndex = 46;
            this.button29.Text = "button29";
            this.button29.UseVisualStyleBackColor = true;
            // 
            // button30
            // 
            this.button30.Location = new System.Drawing.Point(83, 168);
            this.button30.Name = "button30";
            this.button30.Size = new System.Drawing.Size(75, 23);
            this.button30.TabIndex = 45;
            this.button30.Text = "button30";
            this.button30.UseVisualStyleBackColor = true;
            // 
            // button31
            // 
            this.button31.Location = new System.Drawing.Point(1, 168);
            this.button31.Name = "button31";
            this.button31.Size = new System.Drawing.Size(75, 23);
            this.button31.TabIndex = 44;
            this.button31.Text = "button31";
            this.button31.UseVisualStyleBackColor = true;
            // 
            // button32
            // 
            this.button32.Location = new System.Drawing.Point(328, 138);
            this.button32.Name = "button32";
            this.button32.Size = new System.Drawing.Size(75, 23);
            this.button32.TabIndex = 43;
            this.button32.Text = "button32";
            this.button32.UseVisualStyleBackColor = true;
            // 
            // button33
            // 
            this.button33.Location = new System.Drawing.Point(246, 138);
            this.button33.Name = "button33";
            this.button33.Size = new System.Drawing.Size(75, 23);
            this.button33.TabIndex = 42;
            this.button33.Text = "button33";
            this.button33.UseVisualStyleBackColor = true;
            // 
            // button34
            // 
            this.button34.Location = new System.Drawing.Point(164, 138);
            this.button34.Name = "button34";
            this.button34.Size = new System.Drawing.Size(75, 23);
            this.button34.TabIndex = 41;
            this.button34.Text = "button34";
            this.button34.UseVisualStyleBackColor = true;
            // 
            // button35
            // 
            this.button35.Location = new System.Drawing.Point(82, 138);
            this.button35.Name = "button35";
            this.button35.Size = new System.Drawing.Size(75, 23);
            this.button35.TabIndex = 40;
            this.button35.Text = "button35";
            this.button35.UseVisualStyleBackColor = true;
            // 
            // button36
            // 
            this.button36.Location = new System.Drawing.Point(0, 138);
            this.button36.Name = "button36";
            this.button36.Size = new System.Drawing.Size(75, 23);
            this.button36.TabIndex = 39;
            this.button36.Text = "button36";
            this.button36.UseVisualStyleBackColor = true;
            // 
            // button37
            // 
            this.button37.Location = new System.Drawing.Point(329, 108);
            this.button37.Name = "button37";
            this.button37.Size = new System.Drawing.Size(75, 23);
            this.button37.TabIndex = 38;
            this.button37.Text = "button37";
            this.button37.UseVisualStyleBackColor = true;
            // 
            // button38
            // 
            this.button38.Location = new System.Drawing.Point(247, 108);
            this.button38.Name = "button38";
            this.button38.Size = new System.Drawing.Size(75, 23);
            this.button38.TabIndex = 37;
            this.button38.Text = "button38";
            this.button38.UseVisualStyleBackColor = true;
            // 
            // button39
            // 
            this.button39.Location = new System.Drawing.Point(165, 108);
            this.button39.Name = "button39";
            this.button39.Size = new System.Drawing.Size(75, 23);
            this.button39.TabIndex = 36;
            this.button39.Text = "button39";
            this.button39.UseVisualStyleBackColor = true;
            // 
            // button40
            // 
            this.button40.Location = new System.Drawing.Point(83, 108);
            this.button40.Name = "button40";
            this.button40.Size = new System.Drawing.Size(75, 23);
            this.button40.TabIndex = 35;
            this.button40.Text = "button40";
            this.button40.UseVisualStyleBackColor = true;
            // 
            // button41
            // 
            this.button41.Location = new System.Drawing.Point(1, 109);
            this.button41.Name = "button41";
            this.button41.Size = new System.Drawing.Size(75, 23);
            this.button41.TabIndex = 34;
            this.button41.Text = "button41";
            this.button41.UseVisualStyleBackColor = true;
            // 
            // button42
            // 
            this.button42.Location = new System.Drawing.Point(329, 79);
            this.button42.Name = "button42";
            this.button42.Size = new System.Drawing.Size(75, 23);
            this.button42.TabIndex = 33;
            this.button42.Text = "button42";
            this.button42.UseVisualStyleBackColor = true;
            // 
            // button43
            // 
            this.button43.Location = new System.Drawing.Point(247, 79);
            this.button43.Name = "button43";
            this.button43.Size = new System.Drawing.Size(75, 23);
            this.button43.TabIndex = 32;
            this.button43.Text = "button43";
            this.button43.UseVisualStyleBackColor = true;
            // 
            // button44
            // 
            this.button44.Location = new System.Drawing.Point(165, 79);
            this.button44.Name = "button44";
            this.button44.Size = new System.Drawing.Size(75, 23);
            this.button44.TabIndex = 31;
            this.button44.Text = "button44";
            this.button44.UseVisualStyleBackColor = true;
            // 
            // button45
            // 
            this.button45.Location = new System.Drawing.Point(83, 79);
            this.button45.Name = "button45";
            this.button45.Size = new System.Drawing.Size(75, 23);
            this.button45.TabIndex = 30;
            this.button45.Text = "button45";
            this.button45.UseVisualStyleBackColor = true;
            // 
            // button46
            // 
            this.button46.Location = new System.Drawing.Point(1, 79);
            this.button46.Name = "button46";
            this.button46.Size = new System.Drawing.Size(75, 23);
            this.button46.TabIndex = 29;
            this.button46.Text = "button46";
            this.button46.UseVisualStyleBackColor = true;
            this.button46.Click += new System.EventHandler(this.button46_Click);
            // 
            // button47
            // 
            this.button47.Location = new System.Drawing.Point(329, 49);
            this.button47.Name = "button47";
            this.button47.Size = new System.Drawing.Size(75, 23);
            this.button47.TabIndex = 28;
            this.button47.Text = "button47";
            this.button47.UseVisualStyleBackColor = true;
            // 
            // button48
            // 
            this.button48.Location = new System.Drawing.Point(247, 49);
            this.button48.Name = "button48";
            this.button48.Size = new System.Drawing.Size(75, 23);
            this.button48.TabIndex = 27;
            this.button48.Text = "button48";
            this.button48.UseVisualStyleBackColor = true;
            // 
            // button49
            // 
            this.button49.Location = new System.Drawing.Point(83, 49);
            this.button49.Name = "button49";
            this.button49.Size = new System.Drawing.Size(75, 23);
            this.button49.TabIndex = 26;
            this.button49.Text = "button49";
            this.button49.UseVisualStyleBackColor = true;
            // 
            // button50
            // 
            this.button50.Location = new System.Drawing.Point(1, 49);
            this.button50.Name = "button50";
            this.button50.Size = new System.Drawing.Size(75, 23);
            this.button50.TabIndex = 25;
            this.button50.Text = "button50";
            this.button50.UseVisualStyleBackColor = true;
            // 
            // button51
            // 
            this.button51.Location = new System.Drawing.Point(140, 310);
            this.button51.Name = "button51";
            this.button51.Size = new System.Drawing.Size(75, 23);
            this.button51.TabIndex = 3;
            this.button51.Text = "button51";
            this.button51.UseVisualStyleBackColor = true;
            // 
            // radioButton1
            // 
            this.radioButton1.AutoSize = true;
            this.radioButton1.Location = new System.Drawing.Point(14, 236);
            this.radioButton1.Name = "radioButton1";
            this.radioButton1.Size = new System.Drawing.Size(91, 17);
            this.radioButton1.TabIndex = 4;
            this.radioButton1.TabStop = true;
            this.radioButton1.Text = "1 egység hajó";
            this.radioButton1.UseVisualStyleBackColor = true;
            this.radioButton1.CheckedChanged += new System.EventHandler(this.radioButton1_CheckedChanged);
            // 
            // radioButton2
            // 
            this.radioButton2.AutoSize = true;
            this.radioButton2.Location = new System.Drawing.Point(115, 236);
            this.radioButton2.Name = "radioButton2";
            this.radioButton2.Size = new System.Drawing.Size(91, 17);
            this.radioButton2.TabIndex = 5;
            this.radioButton2.TabStop = true;
            this.radioButton2.Text = "2 egység hajó";
            this.radioButton2.UseVisualStyleBackColor = true;
            // 
            // radioButton3
            // 
            this.radioButton3.AutoSize = true;
            this.radioButton3.Location = new System.Drawing.Point(219, 236);
            this.radioButton3.Name = "radioButton3";
            this.radioButton3.Size = new System.Drawing.Size(91, 17);
            this.radioButton3.TabIndex = 6;
            this.radioButton3.TabStop = true;
            this.radioButton3.Text = "3 egység hajó";
            this.radioButton3.UseVisualStyleBackColor = true;
            // 
            // radioButton4
            // 
            this.radioButton4.AutoSize = true;
            this.radioButton4.Location = new System.Drawing.Point(331, 236);
            this.radioButton4.Name = "radioButton4";
            this.radioButton4.Size = new System.Drawing.Size(91, 17);
            this.radioButton4.TabIndex = 7;
            this.radioButton4.TabStop = true;
            this.radioButton4.Text = "4 egység hajó";
            this.radioButton4.UseVisualStyleBackColor = true;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.White;
            this.label1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label1.Location = new System.Drawing.Point(35, 256);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(30, 15);
            this.label1.TabIndex = 8;
            this.label1.Text = "1 db";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.White;
            this.label2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label2.Location = new System.Drawing.Point(140, 256);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(30, 15);
            this.label2.TabIndex = 8;
            this.label2.Text = "2 db";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.Color.White;
            this.label3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label3.Location = new System.Drawing.Point(244, 256);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(30, 15);
            this.label3.TabIndex = 8;
            this.label3.Text = "1 db";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.BackColor = System.Drawing.Color.White;
            this.label4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label4.Location = new System.Drawing.Point(365, 256);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(30, 15);
            this.label4.TabIndex = 8;
            this.label4.Text = "1 db";
            // 
            // tajekoztato
            // 
            this.tajekoztato.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tajekoztato.Location = new System.Drawing.Point(14, 349);
            this.tajekoztato.Name = "tajekoztato";
            this.tajekoztato.Size = new System.Drawing.Size(381, 54);
            this.tajekoztato.TabIndex = 9;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(854, 421);
            this.Controls.Add(this.tajekoztato);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.radioButton4);
            this.Controls.Add(this.radioButton3);
            this.Controls.Add(this.radioButton2);
            this.Controls.Add(this.radioButton1);
            this.Controls.Add(this.button51);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Name = "Form1";
            this.Text = "1";
            this.groupBox1.ResumeLayout(false);
            this.groupBox2.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Button S_C1;
        private System.Windows.Forms.Button S_E5;
        private System.Windows.Forms.Button S_D5;
        private System.Windows.Forms.Button S_C5;
        private System.Windows.Forms.Button S_B5;
        private System.Windows.Forms.Button S_A5;
        private System.Windows.Forms.Button S_E4;
        private System.Windows.Forms.Button S_D4;
        private System.Windows.Forms.Button S_C4;
        private System.Windows.Forms.Button S_B4;
        private System.Windows.Forms.Button S_A4;
        private System.Windows.Forms.Button S_E3;
        private System.Windows.Forms.Button S_D3;
        private System.Windows.Forms.Button S_C3;
        private System.Windows.Forms.Button S_B3;
        private System.Windows.Forms.Button S_A3;
        private System.Windows.Forms.Button S_E2;
        private System.Windows.Forms.Button S_D2;
        private System.Windows.Forms.Button S_C2;
        private System.Windows.Forms.Button S_B2;
        private System.Windows.Forms.Button S_A2;
        private System.Windows.Forms.Button S_E1;
        private System.Windows.Forms.Button S_D1;
        private System.Windows.Forms.Button S_B1;
        private System.Windows.Forms.Button S_A1;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Button button26;
        private System.Windows.Forms.Button button27;
        private System.Windows.Forms.Button button28;
        private System.Windows.Forms.Button button29;
        private System.Windows.Forms.Button button30;
        private System.Windows.Forms.Button button31;
        private System.Windows.Forms.Button button32;
        private System.Windows.Forms.Button button33;
        private System.Windows.Forms.Button button34;
        private System.Windows.Forms.Button button35;
        private System.Windows.Forms.Button button36;
        private System.Windows.Forms.Button button37;
        private System.Windows.Forms.Button button38;
        private System.Windows.Forms.Button button39;
        private System.Windows.Forms.Button button40;
        private System.Windows.Forms.Button button41;
        private System.Windows.Forms.Button button42;
        private System.Windows.Forms.Button button43;
        private System.Windows.Forms.Button button44;
        private System.Windows.Forms.Button button45;
        private System.Windows.Forms.Button button46;
        private System.Windows.Forms.Button button47;
        private System.Windows.Forms.Button button48;
        private System.Windows.Forms.Button button49;
        private System.Windows.Forms.Button button50;
        private System.Windows.Forms.Button button51;
        private System.Windows.Forms.RadioButton radioButton1;
        private System.Windows.Forms.RadioButton radioButton2;
        private System.Windows.Forms.RadioButton radioButton3;
        private System.Windows.Forms.RadioButton radioButton4;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label tajekoztato;
    }
}

