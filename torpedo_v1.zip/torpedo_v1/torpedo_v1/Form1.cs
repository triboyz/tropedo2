﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace torpedo_v1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        int tomb=0;
        int v = 0;
        string gomb;
        string[] helyzet = new string[25];
        int[] hajo = new int[25];
        int[] hajoszam = new int[] { 1, 2, 1, 1 };

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void radioButton1_CheckedChanged(object sender, EventArgs e)
        {
            v = 0;
            tajekoztato.Text = ("Válassz egy cellát!");
            v++;
            
        }
        private void rbutton(object sender, EventArgs e)
        {
            v = 0;
            tajekoztato.Text = ("Válassz egy cellát!");
            if (((RadioButton)sender).Text== "1 egység hajó")
            {
                v=1;
            }
            if (((RadioButton)sender).Text == "2 egység hajó")
            {
                v=2;
            }
            if (((RadioButton)sender).Text == "3 egység hajó")
            {
                v=3;

            }
            if (((RadioButton)sender).Text == "4 egység hajó")
            {
                v=4;
            }

        }
        private void btn_click(object sender, EventArgs e)
        {
            if (hajoszam[0] == 1)
            {
                gomb = ((Button)sender).Name;
                helyzet[tomb] = gomb;
                hajo[tomb] = v;
                ((Button)sender).Enabled = false;
                tomb++;
                hajoszam[0] = -1;
            }
            else if (hajoszam[1] >= 1)
            {
                gomb = ((Button)sender).Name;
                helyzet[tomb] = gomb;
                hajo[tomb] = v;
                ((Button)sender).Enabled = false;
                tomb++;
                hajoszam[1] = -1;
            }
            else if (hajoszam[2] == 1)
            {
                gomb = ((Button)sender).Name;
                helyzet[tomb] = gomb;
                hajo[tomb] = v;
                ((Button)sender).Enabled = false;
                tomb++;
                hajoszam[2] = -1;
            }
            else if (hajoszam[3] == 1)
            {
                gomb = ((Button)sender).Name;
                helyzet[tomb] = gomb;
                hajo[tomb] = v;
                ((Button)sender).Enabled = false;
                tomb++;
                hajoszam[3] = -1;
            }

            int i = 0;
            int val = 0;
            do
            {
                if (hajoszam[0] == 0)
                {
                    val++;
                }
               else if (hajoszam[1] == 0)
                {
                    val++;
                }
               else if (hajoszam[2] == 0)
                {
                    val++;
                }
                else if (hajoszam[3] == 0)
                {
                    val++;
                }

            } while (val>=5);
           
        }

        private void button46_Click(object sender, EventArgs e)
        {

        }
    }
}
